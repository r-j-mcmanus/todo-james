const form = document.getElementById("login-form");
const loginBtn = document.getElementById("login-btn");
const registerBtn = document.getElementById("register-btn");


loginBtn.addEventListener("submit", (event) => 
{
    event.preventDefault(); // prevents reloading on click

    const nameInput = form.elements["username"]
    const passwordInput = form.elements["password"]

    const loginObj = {
        'UserName': nameInput, 
        'Password': passwordInput
    }

    postLogin(loginObj, 'login')

    form.reset(); // remove filled values form the form
}
);

registerBtnBtn.addEventListener("submit", (event) => 
    {
        event.preventDefault(); // prevents reloading on click
    
        const nameInput = form.elements["username"]
        const passwordInput = form.elements["password"]
    
        const loginObj = {
            'UserName': nameInput, 
            'Password': passwordInput
        }
    
        postLogin(loginObj, 'register')
    
        form.reset(); // remove filled values form the form
    }
);

async function postLogin(postBody, endpoint) {
    const url = `http://localhost:5168/${endpoint}`
    
    try {
        const response = await fetch(url, 
            {
                method: "POST",
                body: JSON.stringify(postBody),
                headers: {
                    'Content-Type': 'application/json'
                }
            }
        );

        if (!response.ok) {
            throw new Error("Network response was not ok!", response)
        }

        const data = response.json();
        console.log('Successfully updated the server', data)

        fetchTodos()
    } catch (error) {
        console.log("there was an error", error)
    }
};
