
class LoginRequest{
    required public string UserName;
    required public string Password;
}